from models.carros import Carros

corolla = Carros(modelo="Corolla",
                 marca="Toyota",
                 cor="Preto",
                 ano=2000,
                 placa="IAB-1234",
                 km=100000)

carros = [corolla]

menu = (
    "Digite:\n"
    "C - para CADASTRAR um novo carro.\n"
    "R - para BUSCAR um carro.\n"
    "U - para ATUALIZAR um carro.\n"
    "D - para DELETAR um carro.\n"
    "S - para SAIR.\n"
    "Comando selecionado: "
)


def cadastrar():
    modelo = input("Digite o modelo: ").upper()
    marca = input("Digite a marca: ").upper()
    ano = input("Digite o ano: ").upper()
    cor = input("Digite a cor: ").upper()
    placa = input("Digite a placa: ").upper()
    km = input("Digite a km: ").upper()

    carro = Carros(modelo=modelo,
                   marca=marca,
                   ano=ano,
                   cor=cor,
                   placa=placa,
                   km=km)
    carros.append(carro)
    print("O carro foi cadastrado com sucesso!")
    carro.mostrar_infos()


def buscar():
    placa = input("Digite a placa, ou TODOS para listar todos os carros: ").upper()
    encontrada = False
    for carro in carros:
        if carro.placa == placa or placa == "TODOS":
            carro.mostrar_infos()
            encontrada = True
    if not encontrada:
        print("Carro não encontrado!")


def atualizar():
    placa = input("Digite a placa do carro que deseja atualizar: ").upper()
    for carro in carros:
        if carro.placa == placa:
            print("Carro encontrado! Informe os novos dados (ou deixe em branco para manter).")
            novo_modelo = input(f"Modelo ({carro.modelo}): ").upper()
            nova_marca = input(f"Marca ({carro.marca}): ").upper()
            novo_ano = input(f"Ano ({carro.ano}): ").upper()
            nova_cor = input(f"Cor ({carro.cor}): ").upper()
            nova_km = input(f"KM ({carro.km}): ").upper()

            if novo_modelo: carro.modelo = novo_modelo
            if nova_marca: carro.marca = nova_marca
            if novo_ano: carro.ano = novo_ano
            if nova_cor: carro.cor = nova_cor
            if nova_km: carro.km = nova_km

            print("Carro atualizado com sucesso!")
            carro.mostrar_infos()
            return
    print("Carro não encontrado!")


def deletar():
    placa = input("Digite a placa do carro que deseja deletar: ").upper()
    for carro in carros:
        if carro.placa == placa:
            carros.remove(carro)
            print(f"O carro de placa {placa} foi removido com sucesso!")
            return
    print("Carro não encontrado!")


print('#' * 62)
print('-' * 5 + ' Programa de cadastro de carros iniciado com sucesso! ' + '-' * 5)
print('#' * 62)

# dicionário de operações
operacoes = {
    "C": cadastrar,
    "R": buscar,
    "U": atualizar,
    "D": deletar,
}

while True:
    comando = input(menu).upper()
    if comando == "S":
        print("Programa encerrado!!")
        break
    # procura a função no dicionário
    funcao = operacoes.get(comando)
    if funcao:
        funcao()
    else:
        print("Comando inválido!!!")
                                                                                                                                