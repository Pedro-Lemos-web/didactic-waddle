class Carros:
    """
    classe dedicada ao cadastramento de carros
    entradas: modelo, ano, marca, cor, placa, km
    """
    def __init__(self, modelo, ano, marca, cor, placa, km):
            self.modelo = modelo
            self.cor = cor
            self.ano = ano
            self.marca = marca
            self.placa = placa
            self.km = km
    
    def mostrar_infos(self):
          print("#"*20)
          print(f"O carro de placa {self.placa} é:")
          print("modelo:", self.modelo)
          print("marca:", self.marca)
          print("cor:", self.cor)
          print("km:", self.km)
          print("#"*20 + " "*99)
          